const express = require("express");
const path = require('path')
const port = 8081;
const app = express();

const router = express.Router();

router.use(express.json()); 
router.use(express.urlencoded({ extended: true }));

app.use("/", router);

app.use(express.static(__dirname, {
    extensions: ["html", "htm", "gif", "png","jpeg"],
}))

router.get('/', (req, res) => {
    console.log("Login user page"); 
    res.sendFile (path.join(`${__dirname}/Login_User.html`));
});

router.get('/login_Admin', (req, res) => {
    console.log("Login admin page"); 
    res.sendFile (path.join(`${__dirname}/Login_Admin.html`));
});

router.get('/Home', (req, res) => {
    console.log("Home page"); 
    res.sendFile (path.join(`${__dirname}/Home.html`));
});

router.get('/Game', (req, res) => {
    console.log("Game page"); 
    res.sendFile (path.join(`${__dirname}/Game.html`));
});

router.get('/Cart', (req, res) => {
    console.log("Cart page"); 
    res.sendFile (path.join(`${__dirname}/Cart.html`));
});

router.get('/Library', (req, res) => {
    console.log("Library page"); 
    res.sendFile (path.join(`${__dirname}/Library.html`));
});

router.get('/Wishlist', (req, res) => {
    console.log("Wishlist page"); 
    res.sendFile (path.join(`${__dirname}/Wishlist.html`));
});

router.get('/Payment', (req, res) => {
    console.log("Payment page"); 
    res.sendFile (path.join(`${__dirname}/Payment.html`));
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
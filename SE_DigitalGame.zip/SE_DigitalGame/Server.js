const mysql = require("mysql2");
const path = require("path");
const dotenv = require("dotenv");
const express = require("express");
const cors = require("cors");

dotenv.config();

const app = express();
const router = express.Router();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use(express.static(__dirname + "/public"));
app.use(router);

const connection = mysql.createConnection({
    host: process.env.MYSQL_HOST,
    user: process.env.MYSQL_USERNAME,
    password: process.env.MYSQL_PASSWORD,
    database: process.env.MYSQL_DATABASE,
});

connection.connect((err) => {
    if (err) {
        console.error("Error connecting to MySQL database: " + err.stack);
        return;
    }
    console.log("Connected to MySQL database as ID " + connection.threadId);
});

const corsOptions = {
    origin: 'http://localhost:8081',
    methods: 'GET,POST,PUT,DELETE'
  };
  
router.use(cors());

// User login
router.post('/login/user', (req, res) => {
    const { username, password } = req.body;
    const query = 'SELECT * FROM user WHERE username = ? AND password = ?';
    connection.query(query, [username, password], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        if (results.length > 0) {
            res.json({ success: true });
        } else {
            res.status(401).json({ success: false, error: 'Invalid username or password' });
        }
    });
});

// Admin login
router.post('/login/admin', (req, res) => {
    const { username_admin, password_admin } = req.body;
    const query = 'SELECT * FROM admin WHERE username_admin = ? AND password_admin = ?';
    connection.query(query, [username_admin, password_admin], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        if (results.length > 0) {
            res.json({ success: true });
        } else {
            res.status(401).json({ success: false, error: 'Invalid username or password' });
        }
    });
});

// ---------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------- //


router.get('/detail/:gameID', async (req, res) => {
    const { gameID } = req.params;
    if (!gameID) {
        return res.status(400).json({ error: "Game ID is required" });
    }

    try {
        const gameDetailsQuery = 'SELECT * FROM game WHERE gID = ?';
        const gameDetails = await queryDatabase(gameDetailsQuery, [gameID]);

        if (gameDetails.length === 0) {
            return res.status(404).json({ error: "Game not found" });
        }

        res.json(gameDetails[0]);
    } catch (error) {
        console.error('Database Error:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

function queryDatabase(query, params) {
    return new Promise((resolve, reject) => {
        connection.query(query, params, (err, results) => {
            if (err) return reject(err);
            resolve(results);
        });
    });
}

router.post('/game1', async (req, res) => {
    const gameIDs = req.body;
    
    // Check if gameIDs is an array of gameID objects
    if (!Array.isArray(gameIDs) || gameIDs.some(item => !item.gameID)) {
        return res.status(400).json({ error: 'Invalid input data format' });
    }

    try {
        // Map each gameID to a database query and use Promise.all to handle all queries concurrently
        const gameDetailsPromises = gameIDs.map(item => {
            const query = 'SELECT * FROM game WHERE gID = ?';
            return queryDatabase(query, [item.gameID])
                .then(results => results[0])  // Return the first result if found
                .catch(err => {
                    console.error('Error querying database:', err);
                    throw new Error('Database query failed');
                });
        });

        // Await all queries to complete and filter out any undefined (not found) results
        const games = (await Promise.all(gameDetailsPromises)).filter(game => game);

        res.json(games);  // Send the list of game details
    } catch (error) {
        console.error('Error processing requests:', error);
        res.status(500).send('Internal Server Error');
    }
});

// ---------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------- //

router.get('/get_games', async (req, res) => {
    const { search } = req.query; 
    
    try {
        let query = 'SELECT gID, gName, image_url FROM game';
        const params = [];
        
        if (search) {
            query += ' WHERE gName LIKE ?';
            params.push(`%${search}%`);
        }
        
        const games = await queryDatabase(query, params);
        res.json(games);
    } catch (error) {
        console.error('Database Error:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// ---------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------- //

//Cart and Wishlist
app.get('/detail/:gameID', (req, res) => {
    const gameID = req.params.gameID;
    console.log(`Fetching details for game ID: ${gameID}`);
    connection.query('SELECT * FROM game WHERE gID = ?', [gameID], (error, results) => {
        if (error) {
            console.error('Error retrieving data:', error);
            res.status(500).send('Error retrieving data');
            return;
        }
        if (results.length === 0) {
            console.log(`No game found with ID: ${gameID}`);
            res.status(404).send('Game not found');
            return;
        }
        console.log('Game details:', results[0]);
        res.json(results[0]);
    });
});

// ---------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------- //
//                                          Admin
// ---------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------- //

// Fetch all games
app.get('/get_GameData', (req, res) => {
    const query = 'SELECT gID, gName, description, genre, creator, price, os, processor, memory, graphics, storage FROM game';
    connection.query(query, (err, results) => {
        if (err) return res.status(500).send("Database error");
        res.json({ data: results });
    });
});

// Update game data
app.post('/update_GameData', (req, res) => {
    const { gID, gName, description, genre, creator, price, os, processor, memory, graphics, storage } = req.body;
    const query = 'UPDATE game SET gName = ?, description = ?, genre = ?, creator = ?, price = ?, os = ?, processor = ?, memory = ?, graphics = ?, storage = ? WHERE gID = ?';
    connection.query(query, [gName, description, genre, creator, price, os, processor, memory, graphics, storage, gID], (err, results) => {
        if (err) return res.status(500).send("Update failed");
        res.json({ message: "Game updated successfully" });
    });
});


class DbGameData {
    static getDbServiceInstance() {
        return instance ? instance : new DbGameData();
    }

    async getAllGameData() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT gID, gName, description, price, os, processor, memory, graphics, storage FROM game;`;
                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                });
            });
            return response;
        } catch (error) {
            console.log(error);
        }
    }

    async updateGameData(gID, gName, description, price, os, processor, memory, graphics, storage) {
        try {
            const query = `UPDATE game SET gName = ?, description = ?, price = ?, os = ?, processor = ?, memory = ?, graphics = ?, storage = ? WHERE gID = ?;`;
            await new Promise((resolve, reject) => {
                connection.query(query, [gName, description, price, os, processor, memory, graphics, storage, gID], (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                });
            });
        } catch (error) {
            console.log(error);
        }
    }
}

module.exports = DbGameData;



// ---------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------- //


router.post('/insert', async (req, res) => {
    const { cardNumber, expiryDate, cvv, gameNames } = req.body;

    // Calculate total price based on game prices
    let totalPrice = 0;
    for (const gameName of gameNames) {
        const query = 'SELECT price FROM game WHERE gName = ?';
        const results = await queryDatabase(query, [gameName]);
        if (results.length > 0) {
            const price = results[0].price === 'Free' ? 0 : parseFloat(results[0].price);
            totalPrice += price;
        }
    }

    // Get current date and time in Thailand time zone
    const purchaseDate = new Date().toISOString().slice(0, 19).replace('T', ' ');
    // Prepare the SQL query
    const query = `
        INSERT INTO payments (game_name, purchase_date, total_price, card_number, expiry_date, cvv)
        VALUES (?, ?, ?, ?, ?, ?)`;

    const values = [gameNames.join(', '), purchaseDate, totalPrice, cardNumber, expiryDate, cvv];

    // Insert payment data into the database
    connection.query(query, values, (err, result) => {
        if (err) {
            console.error('Error inserting data:', err);
            return res.status(500).json({ success: false, message: 'Internal Server Error' });
        }

        console.log('Payment data inserted:', result);
        res.json({ success: true });
    });
});

// ---------------------------------------------------------------------------------------------- //
// ---------------------------------------------------------------------------------------------- //


router.get("/", (req, res) => {
    res.send("Welcome to the root endpoint");
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

DROP DATABASE IF EXISTS digitalgame;
CREATE DATABASE IF NOT EXISTS `digitalgame` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `digitalgame`;

CREATE TABLE `user` (
    `username` VARCHAR(255) NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`username`)
);

INSERT INTO `user` (`username`, `password`) VALUES
('itthisak.kam@mahidol.edu', 'ff22ff22'),
('suphatchaya.aic@mahidol.edu', 'ss22ss22'),
('thanakrit.jit@mahidol.edu', 'ee22ee22'),
('krittin.pro@mahidol.edu', 'tt22tt22'),
('parkait.kai@mahidol.edu', 'jj22jj22'),
('user1234@mahidol.edu', 'ii22ii22');

CREATE TABLE `admin` (
    `username_admin` VARCHAR(255) NOT NULL,
    `password_admin` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`username_admin`)
);

INSERT INTO `admin` (`username_admin`, `password_admin`) VALUES
('thanakrit@mahidol.edu', 'ii22ii22'),
('admin123@mahidol.edu', 'ii22ii22');

-- Login


CREATE TABLE `game` (
    `gID` CHAR(10) NOT NULL,
    `gName` VARCHAR(255) NOT NULL,
    `description` VARCHAR(1000) NOT NULL,
    `genre` VARCHAR(255) NOT NULL,
    `creator` VARCHAR(255) NOT NULL,
    `price` VARCHAR(20) NOT NULL,
    `os` VARCHAR(255) NOT NULL,
    `processor` VARCHAR(255) NOT NULL,
    `memory` VARCHAR(255) NOT NULL,
    `graphics` VARCHAR(255) NOT NULL,
    `storage` VARCHAR(255) NOT NULL,
    `image_url` VARCHAR(255) DEFAULT NULL,
    PRIMARY KEY (`gID`)
);


INSERT INTO `game` (`gID`, `gName`, `description`, `genre`, `creator`, `price`, `os`, `processor`, `memory`, `graphics`, `storage`, `image_url`) VALUES
('001', 'Counter-Strike 2', 'For over two decades, Counter-Strike has offered an elite competitive experience, one shaped by millions of players from across the globe. And now the next chapter in the CS story is about to begin. This is Counter-Strike 2.', 
'FPS', 'Valve', 
'Free', 'Windows® 10', 
'4 hardware CPU threads - Intel® Core™ i5 750 or higher', 
'8 GB RAM', 
'Video card must be 1 GB or more and should be a DirectX 11',
'85 GB available space',	
'http://localhost:8081/img/cs2.jpeg'),
('002', 'Dota2', 'Every day, millions of players worldwide enter battle as one of over a hundred Dota heroes. And no matter if it''s their 10th hour of play or 1,000th, there''s always something new to discover. With regular updates that ensure a constant evolution of gameplay, features, and heroes, Dota 2 has taken on a life of its own.',
'MOBA', 'Valve', 
'Free', 'Windows 7 or newer', 
'Dual core from Intel or AMD at 2.8 GHz',
'4 GB RAM',
'NVIDIA GeForce 8600/9600GT, ATI/AMD Radeon HD2600/3600',
'60 GB available space',
'http://localhost:8081/img/dota2.jpg'),
('003', 'Stardew Valley', 'You''ve inherited your grandfather''s old farm plot in Stardew Valley. Armed with hand-me-down tools and a few coins, you set out to begin your new life. Can you learn to live off the land and turn these overgrown fields into a thriving home?', 
'Farm', 'Eric Barone',
'315', 'Windows Vista or greater',
'2 Ghz',
'2 GB RAM',
'256 mb video memory, shader model 3.0+',
'500 MB available space',	
'http://localhost:8081/img/stardew.jpg'),
('004', 'PUBG: BATTLEGROUNDS', 'PUBG: BATTLEGROUNDS for free. Land on strategic locations, loot weapons and supplies, and survive to become the last team standing across various, diverse Battlegrounds. Squad up and join the Battlegrounds for the original Battle Royale experience that only PUBG', 
'Battle royale', 'Brendan Greene', 
'Free', 'OS: 64-bit Windows 10',
'Intel Core i5-4430 / AMD FX-6300',
'8 GB RAM',
'NVIDIA GeForce GTX 960 2GB / AMD Radeon R7 370 2GB',
'40 GB available space',	
'http://localhost:8081/img/pubg.jpg'),
('005', 'Grand Theft Auto V', 'Grand Theft Auto V for PC offers players the option to explore the award-winning world of Los Santos and Blaine County in resolutions of up to 4k and beyond, as well as the chance to experience the game running at 60 frames per second.', 
'Action-adventure', 'Rockstar Games', 
'939', 'Windows 10 64 Bit',
'Intel Core 2 Quad CPU Q6600 @ 2.40GHz (4 CPUs) / AMD Phenom 9850 Quad-Core Processor (4 CPUs) @ 2.5GHz',
'4 GB RAM',
'NVIDIA 9800 GT 1GB / AMD HD 4870 1GB (DX 10, 10.1, 11)',
'120 GB available space',	
'http://localhost:8081/img/GTAV.jpg'),
('006', 'Deadlock', 'Deadlock is a multiplayer game in early development.', 
'Third-person shooter', 'Valve',
'Free', 'Window 10/11',
'Intel i5 9400, AMD Ryzen 3600',
'16 GB RAM',
'NVIDIA GTX 1060 (6G VRAM)',
'40 GB available space',	
'http://localhost:8081/img/Deadlock.jpg'),
('007', 'War thunder', 'War Thunder is the most comprehensive free-to-play, cross-platform, MMO military game dedicated to aviation, armoured vehicles, and naval craft, from the early 20th century to the most advanced modern combat units. Join now and take part in major battles on land, in the air, and at sea.', 
'vehicular combat', 'Gaijin Entertainment',
'Free', 'Windows 10/11 (64bit)',
'Intel Core i5 or Ryzen 5 3600 or better',
'16 GB RAM',
'DirectX 11 level video card or higher and drivers: Nvidia GeForce 1060 and higher, Radeon RX 570 and higher',
'95 GB available space',	
'http://localhost:8081/img/WarThunder.jpg'),
('008', 'InZOI', 'Create your unique story by controlling and observing the lives of ''Zois''. Customize characters and build houses using inZOI''s easy-to-use tools to live the life of your dreams and experience the different emotions of life created by its deep and detailed simulation.', 
'Life simulation', 'Krafton',
'Free', 'Windows 10/11',
'Intel i5 10400, AMD Ryzen 3600',
'12 GB RAM',
'NVIDIA RTX 2060 (8G VRAM), AMD Radeon RX 5600 XT',
'60 GB available space',	
'http://localhost:8081/img/InZOI.jpg'),
('009', 'Delta Force', 'Delta Force, the iconic free-to-play first-person tactical shooter is now back! With 25 years of defining the genre, Delta Force now features three distinct gameplay modes: large-scale PvP warfare, intense extraction shooter action, and the legendary Black Hawk Down campaign.', 
'FPS', 'TiMi Studios',
'Free', 'Windows 10 64 bit',
'Intel Core i5-6500 / AMD Ryzen 5 1500x',
'16 GB RAM',
'Nvidia Geforce GTX 1060 5G / AMD RX5500 XT / Intel Arc A580',
'50 GB available space',	
'http://localhost:8081/img/DeltaForce.jpg'),
('010', 'Coral Island', 'Coral Island is a vibrant and laid-back reimagining of farm sim games. Be who you want and experience enchanting island living at your own pace—live off the land, nurture animals, build relationships with a diverse cast of townsfolk, and make the world around you a more vital and harmonious place.', 
'Farm', 'Stairway Games',
'580', 'Windows 10 64 bit',
'Intel i3 Processor',
'6 GB RAM',
'Nvidia GeForce GTX 660 2GB',
'8 GB available space',	'http://localhost:8081/img/CoralIsland.jpg');

CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    game_name VARCHAR(255),
    purchase_date DATETIME,
    total_price DECIMAL(10, 2),
    card_number VARCHAR(16),
    expiry_date VARCHAR(7),  -- Format: MM/YYYY
    cvv VARCHAR(3)
);